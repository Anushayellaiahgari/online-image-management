document.getElementById('addButton').addEventListener('click', function() {
    const url = document.getElementById('imageUrl').value;
    const error = document.getElementById('error');
    const imagesContainer = document.getElementById('imagesContainer');

    const imgDisplay = new Image();
    imgDisplay.src = url;

    imgDisplay.onload = function() {
        const imageContainer = document.createElement('div');
        imageContainer.classList.add('image-container');
        
        const deleteButton = document.createElement('button');
        deleteButton.classList.add('delete-button');
        deleteButton.innerText = 'Delete Image';

        // Append the image and button to the container
        imageContainer.appendChild(imgDisplay);
        imageContainer.appendChild(deleteButton);
        imagesContainer.appendChild(imageContainer);

        // Clear the input field after adding the image
        document.getElementById('imageUrl').value = '';
        
        // Show error message if necessary
        error.style.display = 'none';

        // Add event listener to delete the image
        deleteButton.addEventListener('click', function() {
            imagesContainer.removeChild(imageContainer);
        });
    };

    imgDisplay.onerror = function() {
        error.style.display = 'block';
        alert('Invalid URL');
    };
});
